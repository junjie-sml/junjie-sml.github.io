const navigation=document.querySelector('#navigation');
const menuToggle=document.querySelector('.menu-toggle');
function closeMenu(){ navigation.classList.remove('is-open'); menuToggle.setAttribute('aria-expanded','false'); }
menuToggle.addEventListener('click',()=>{
 const open=menuToggle.getAttribute('aria-expanded')!=='true';
 menuToggle.setAttribute('aria-expanded',String(open)); navigation.classList.toggle('is-open',open);
});
navigation.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&menuToggle.getAttribute('aria-expanded')==='true'){closeMenu();menuToggle.focus();}});
document.addEventListener('click',event=>{if(!event.target.closest('.header-inner'))closeMenu();});
window.matchMedia('(min-width:1024px)').addEventListener('change',closeMenu);
const contactForm=document.querySelector('#contact-form');
if(contactForm){
 contactForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(!contactForm.reportValidity())return;
  const values=new FormData(contactForm);
  const subject=String(values.get('subject')).trim();
  const body=`From: ${String(values.get('name')).trim()}\nEmail: ${String(values.get('email')).trim()}\n\n${String(values.get('message')).trim()}`;
  window.location.href=`mailto:junjieta@andrew.cmu.edu?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
 });
}
