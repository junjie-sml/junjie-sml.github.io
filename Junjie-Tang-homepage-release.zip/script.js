const navigation=document.querySelector('#navigation');
const menuToggle=document.querySelector('.menu-toggle');
function closeMenu(){ navigation.classList.remove('is-open'); menuToggle.setAttribute('aria-expanded','false'); }
menuToggle.addEventListener('click',()=>{
 const open=menuToggle.getAttribute('aria-expanded')!=='true';
 menuToggle.setAttribute('aria-expanded',String(open)); navigation.classList.toggle('is-open',open);
});
navigation.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&menuToggle.getAttribute('aria-expanded')==='true'){closeMenu();menuToggle.focus();}});
document.addEventListener('click',event=>{if(!event.target.closest('.header-inner'))closeMenu();});
window.matchMedia('(min-width:1024px)').addEventListener('change',closeMenu);
const contactForm=document.querySelector('#contact-form');
if(contactForm){
 contactForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(!contactForm.reportValidity())return;
  const values=new FormData(contactForm);
  const subject=String(values.get('subject')).trim();
  const body=`From: ${String(values.get('name')).trim()}\nEmail: ${String(values.get('email')).trim()}\n\n${String(values.get('message')).trim()}`;
  window.location.href=`mailto:junjieta@andrew.cmu.edu?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
 });
}

// Briefly identify the paper reached through a publication anchor.
if(document.querySelector('.publication[id]')){
 let highlightedPaper;
 let highlightFrame;
 let highlightTimer;
 function clearPublicationHighlight(){
  cancelAnimationFrame(highlightFrame);
  clearTimeout(highlightTimer);
  highlightedPaper?.classList.remove('is-arrival-highlighted');
  highlightedPaper=null;
 }
 function highlightLinkedPublication(){
  clearPublicationHighlight();
  let id;
  try{id=decodeURIComponent(location.hash.slice(1));}catch{return;}
  const paper=document.getElementById(id);
  if(!paper?.matches('.publication'))return;
  // Let the browser finish its native fragment scroll before showing the cue.
  highlightFrame=requestAnimationFrame(()=>{
   highlightFrame=requestAnimationFrame(()=>{
    highlightedPaper=paper;
    paper.classList.add('is-arrival-highlighted');
    const reducedMotion=window.matchMedia('(prefers-reduced-motion:reduce)').matches;
    highlightTimer=setTimeout(clearPublicationHighlight,reducedMotion?1200:2400);
   });
  });
 }
 window.addEventListener('pageshow',highlightLinkedPublication);
 window.addEventListener('hashchange',highlightLinkedPublication);
 document.addEventListener('click',event=>{
  if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  const link=event.target.closest('a[href]');
  if(!link||link.hasAttribute('download')||(link.target&&link.target!=='_self'))return;
  const target=new URL(link.href);
  if(target.origin===location.origin&&target.pathname===location.pathname&&target.search===location.search&&target.hash===location.hash){
   highlightLinkedPublication();
  }
 });
}
